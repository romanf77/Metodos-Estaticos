﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_Lab_II___3
{
    class TIEMPO
    {
        //atributos
        public int cantidad;

        //constructor
        public TIEMPO(int cantidad)
        {
            this.cantidad = cantidad;
        }


    }
}
