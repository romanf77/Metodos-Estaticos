﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_Lab_II___3
{
    enum eFabricante
    {
        ford, 
        chevrolet,
        honda,
    }
}
