﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    class Numero
    {

       public double numero1;
       public double numero2;

        //constructor
        public Numero()
        {   
            //codigo
        }

        //metodos
        public double getNumero()
        {
            //codigo
        }
       

        public double Numero(double numero)
        {
            //codigo
        }
        
        public void Numero(string numero)
        {
            //codigo
        }
        
        public void setNumero(string numero)
        {   
            //codigo
        }

        public double validarNumero(string numeroString)
        {
            //codigo
        }
        
    }
}
