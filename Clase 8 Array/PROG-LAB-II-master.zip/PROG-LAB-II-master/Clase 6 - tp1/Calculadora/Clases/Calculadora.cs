﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    class Calculadora
    {
        //metodos

        double resultado;

        public double operar(Numero.numero1, Numero.numero2, string operador)
        {
            //codigo
        }

        private static validarOperador(string operador)
        {
            //codigo
        }

    }
}
